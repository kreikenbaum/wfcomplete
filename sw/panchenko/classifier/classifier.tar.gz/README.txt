STEPS:
 - install dependencies
 (- build libSVM)
 - run evaluation

REQUIREMENTS:
 - dependencies for libSVM (refer to libSVM README) 
 - install 
      - python-tldextract (https://pypi.python.org/pypi/tldextract)
      - python-natsort (https://pypi.python.org/pypi/natsort)

RUN:
 - open-world (filtered link): e.g. python eval.py -ffg Foreground_40I_100Cum_1125_TLS -fbg Background_100Cum_111884_TLS -rmtmp -webpage -dirin ../data/ -dirout ../output/ -svm ../libsvm-3.20/
  - open-world (filtered domain): e.g. python eval.py -ffg Foreground_40I_100Cum_1125_TLS -fbg Background_100Cum_111884_TLS -rmtmp -website -dirin ../data/ -dirout ../output/ -svm ../libsvm-3.20/
 - closed-world: e.g. python eval.py -fcw FILENAME -rmtmp -dirin ../data/ -dirout ../output/ -svm ../libsvm-3.20/
